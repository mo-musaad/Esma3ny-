# Egyptian-Sign-Language-Translator
"اسمعني" is an Egyptian mobile application helps deaf people to communicate properly and easily with everyone. 
It enables the deaf person to capture a video of himself/herself doing the sign, then it applies our translation logic and displays what the deaf person wants to say.  
