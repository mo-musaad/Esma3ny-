venv\Scripts\activate
set FLASK_APP=esm el app
set FLASK_ENV=development
flask run

flask --app app --debug run